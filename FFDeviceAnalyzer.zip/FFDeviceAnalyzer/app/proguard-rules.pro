# Keep model classes for reflection-free stability (data classes used in UI state)
-keep class com.ffanalyzer.deviceanalyzer.data.model.** { *; }

# Compose
-dontwarn androidx.compose.**
