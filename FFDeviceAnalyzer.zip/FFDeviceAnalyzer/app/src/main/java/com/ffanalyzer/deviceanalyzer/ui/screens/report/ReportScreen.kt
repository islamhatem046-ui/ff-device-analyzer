package com.ffanalyzer.deviceanalyzer.ui.screens.report

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.components.EmptyStateMessage
import com.ffanalyzer.deviceanalyzer.ui.components.PrimaryActionButton
import com.ffanalyzer.deviceanalyzer.util.buildDeviceReportText

@Composable
fun ReportScreen(viewModel: AppViewModel) {
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val scores by viewModel.performanceScores.collectAsState()
    val recommendation by viewModel.recommendation.collectAsState()
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.report_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        val info = deviceInfo
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            if (info == null) {
                EmptyStateMessage(
                    title = stringResource(R.string.report_title),
                    subtitle = stringResource(R.string.start_analysis)
                )
            } else {
                val reportText = remember(info, scores, recommendation) {
                    buildDeviceReportText(info, scores, recommendation)
                }

                Text(
                    stringResource(R.string.report_disclaimer),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))

                Card(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    SelectionContainer {
                        Text(
                            reportText,
                            modifier = Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { clipboard.setText(AnnotatedString(reportText)) },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.copy_report)) }

                    Button(
                        onClick = {
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, reportText)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, null))
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text(stringResource(R.string.share_report)) }
                }
            }
        }
    }
}
