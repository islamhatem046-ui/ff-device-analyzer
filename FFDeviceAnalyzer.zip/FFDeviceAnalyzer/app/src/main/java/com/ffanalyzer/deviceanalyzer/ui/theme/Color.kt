package com.ffanalyzer.deviceanalyzer.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette: deep graphite + electric orange/teal accent — distinct from common
// gaming-utility apps' red/black look, without copying any specific existing product.
val GraphiteBlack = Color(0xFF0D1117)
val GraphitePanel = Color(0xFF161B22)
val GraphiteCard = Color(0xFF1C2330)
val GraphiteBorder = Color(0xFF2A3242)

val AccentOrange = Color(0xFFFF8A3D)
val AccentOrangeDim = Color(0xFFB35A22)
val AccentTeal = Color(0xFF3DDCB8)
val AccentTealDim = Color(0xFF1F8A70)

val StatusGreen = Color(0xFF4CD964)
val StatusYellow = Color(0xFFF5C542)
val StatusOrange = Color(0xFFFF9F45)
val StatusRed = Color(0xFFFF4D4F)

val TextPrimaryDark = Color(0xFFF2F4F8)
val TextSecondaryDark = Color(0xFFA3AEC2)

val LightBackground = Color(0xFFF6F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFEFF1F6)
val TextPrimaryLight = Color(0xFF12151C)
val TextSecondaryLight = Color(0xFF5B6472)
