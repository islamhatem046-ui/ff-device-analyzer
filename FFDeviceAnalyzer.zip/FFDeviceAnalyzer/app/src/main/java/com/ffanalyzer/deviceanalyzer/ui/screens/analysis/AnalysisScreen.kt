package com.ffanalyzer.deviceanalyzer.ui.screens.analysis

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.data.model.TestStage
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.UiLoadState

@Composable
fun AnalysisScreen(
    viewModel: AppViewModel,
    onFinished: () -> Unit
) {
    val progress by viewModel.testProgress.collectAsState()
    val loadState by viewModel.loadState.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.runFullAnalysis()
    }

    LaunchedEffect(loadState) {
        if (loadState == UiLoadState.Success) onFinished()
    }

    Scaffold { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            CircularProgressIndicator(
                progress = { (progress?.overallProgressPercent ?: 0) / 100f },
                modifier = Modifier.size(96.dp)
            )
            Spacer(Modifier.height(24.dp))
            Text(
                stringResource(R.string.analyzing_device),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                stageLabel(progress?.stage),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (progress?.stoppedForHeat == true) {
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.stopped_due_to_heat),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            if (loadState is UiLoadState.Error) {
                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.error_generic),
                    color = MaterialTheme.colorScheme.error
                )
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { viewModel.runFullAnalysis() }) {
                    Text(stringResource(R.string.retry))
                }
            }
        }
    }
}

@Composable
private fun stageLabel(stage: TestStage?): String = when (stage) {
    TestStage.CPU -> stringResource(R.string.stage_cpu)
    TestStage.GPU -> stringResource(R.string.stage_gpu)
    TestStage.RAM -> stringResource(R.string.stage_ram)
    TestStage.STORAGE -> stringResource(R.string.stage_storage)
    TestStage.THERMAL -> stringResource(R.string.stage_thermal)
    TestStage.BATTERY -> stringResource(R.string.stage_battery)
    TestStage.DONE, null -> stringResource(R.string.loading)
}
