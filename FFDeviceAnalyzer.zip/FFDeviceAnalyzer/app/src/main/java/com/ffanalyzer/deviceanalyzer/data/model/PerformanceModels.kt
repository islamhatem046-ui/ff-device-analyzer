package com.ffanalyzer.deviceanalyzer.data.model

/** Scores are always 0-100, produced by PerformanceAnalyzer from short, safe local tests. */
data class PerformanceScores(
    val cpuScore: Int,
    val gpuScore: Int,
    val ramScore: Int,
    val storageScore: Int,
    val thermalScore: Int,
    val batteryScore: Int,
    val overallScore: Int,
    val testWasStoppedEarlyDueToHeat: Boolean = false,
    val uiFrameStats: AvailableValue<FrameStats> // measured on the app's own Compose UI, never claimed as game FPS
)

data class FrameStats(
    val currentFps: Double,
    val averageFps: Double,
    val onePercentLowFps: Double?,
    val averageFrameTimeMs: Double,
    val stabilityPercent: Double // 0-100, based on frame time variance
)

enum class TestStage { CPU, GPU, RAM, STORAGE, THERMAL, BATTERY, DONE }

data class TestProgress(
    val stage: TestStage,
    val stageProgressPercent: Int,
    val overallProgressPercent: Int,
    val stoppedForHeat: Boolean = false
)

enum class SupportedGame(val displayKey: String) {
    FREE_FIRE("game_free_fire"),
    FREE_FIRE_MAX("game_free_fire_max")
}

data class GameInfo(
    val game: SupportedGame,
    val packageName: String,
    val isInstalled: Boolean,
    val versionName: AvailableValue<String>,
    val versionCode: AvailableValue<Long>
)

enum class GraphicsQuality { SMOOTH, BALANCED, HD, ULTRA_HD }
enum class FrameRateOption { LOW, MEDIUM, HIGH, ULTRA, EXTREME_90, EXTREME_120 }
enum class ResolutionOption { LOW, MEDIUM, HIGH, ULTRA_HD_OPT }
enum class ShadowOption { OFF, LOW, HIGH }
enum class AntiAliasingOption { OFF, ON }
enum class TristateOption { LOW, MEDIUM, HIGH }

/** A single recommended setting + the human-readable reason behind it (required by spec §4). */
data class RecommendedSetting<T>(
    val value: T,
    val reasonKey: String,
    val reasonArgs: List<String> = emptyList(),
    val availableInCurrentGameVersion: Boolean = true
)

data class RecommendationResult(
    val profile: PerformanceProfile,
    val profileConfidencePercent: Int,
    val profileReasonKey: String,
    val graphicsQuality: RecommendedSetting<GraphicsQuality>,
    val frameRate: RecommendedSetting<FrameRateOption>,
    val resolution: RecommendedSetting<ResolutionOption>,
    val shadow: RecommendedSetting<ShadowOption>,
    val antiAliasing: RecommendedSetting<AntiAliasingOption>,
    val textureQuality: RecommendedSetting<TristateOption>,
    val effects: RecommendedSetting<TristateOption>,
    val autoAdjustGraphicsRecommended: Boolean
)

enum class PerformanceProfile(val labelKey: String) {
    MAXIMUM_FPS("profile_max_fps"),
    BALANCED("profile_balanced"),
    BATTERY_SAVER("profile_battery_saver"),
    LOW_HEAT("profile_low_heat"),
    BEST_VISUAL_QUALITY("profile_best_visual")
}

/** Weighted factors used by the rule+weight based Recommendation Engine (spec §14). */
data class RecommendationFactors(
    val cpuScore: Int,
    val gpuScore: Int,
    val ramScore: Int,
    val ramTotalGb: Double,
    val refreshRateHz: Float,
    val androidApiLevel: Int,
    val thermalStatus: ThermalLevel,
    val batteryLevelPercent: Int,
    val isCharging: Boolean,
    val availableStorageGb: Double,
    val overallScore: Int
)
