package com.ffanalyzer.deviceanalyzer.util

import com.ffanalyzer.deviceanalyzer.data.model.DeviceInfo
import com.ffanalyzer.deviceanalyzer.data.model.PerformanceScores
import com.ffanalyzer.deviceanalyzer.data.model.RecommendationResult

/**
 * Builds the plain-text device report (spec §10). Every value goes through getOrNull() with an
 * explicit "N/A" fallback rather than any invented placeholder, and estimated values are marked.
 */
fun buildDeviceReportText(
    info: DeviceInfo,
    scores: PerformanceScores?,
    recommendation: RecommendationResult?
): String {
    val na = "N/A (not available on this device/Android version)"
    fun <T> Any?.orNa(): String = this?.toString() ?: na

    val sb = StringBuilder()
    sb.appendLine("===== FF Device Analyzer — Device Report =====")
    sb.appendLine()
    sb.appendLine("[Device]")
    sb.appendLine("Manufacturer: ${info.system.manufacturer}")
    sb.appendLine("Model: ${info.system.model}")
    sb.appendLine("Android: ${info.system.androidVersion} (API ${info.system.apiLevel})")
    sb.appendLine("Security patch: ${info.system.securityPatch.getOrNull().orNa()}")
    sb.appendLine()
    sb.appendLine("[CPU]")
    sb.appendLine("Architecture: ${info.cpu.architecture}")
    sb.appendLine("Cores: ${info.cpu.coreCount}")
    sb.appendLine("Chipset: ${info.cpu.cpuName.getOrNull().orNa()}")
    sb.appendLine()
    sb.appendLine("[GPU]")
    sb.appendLine("Renderer: ${info.gpu.renderer.getOrNull().orNa()}")
    sb.appendLine("OpenGL ES: ${info.gpu.openGlEsVersion.getOrNull().orNa()}")
    sb.appendLine("Vulkan: ${info.gpu.vulkanSupported.getOrNull()?.let { if (it) "Supported (${info.gpu.vulkanVersion.getOrNull().orNa()})" else "Not supported" } ?: na}")
    sb.appendLine()
    sb.appendLine("[RAM]")
    sb.appendLine("Total: ${UnitFormatter.formatGb(info.ram.totalBytes)}")
    sb.appendLine("Available: ${UnitFormatter.formatGb(info.ram.availableBytes)}")
    sb.appendLine("Used: ${UnitFormatter.formatPercent(info.ram.usedPercent)}")
    sb.appendLine()
    sb.appendLine("[Display]")
    sb.appendLine("Resolution: ${info.display.widthPx}x${info.display.heightPx}, ${info.display.densityDpi} dpi")
    sb.appendLine("Refresh rate: ${info.display.refreshRateHz.getOrNull()?.let { "${it.toInt()} Hz" } ?: na}")
    sb.appendLine()
    sb.appendLine("[Battery]")
    sb.appendLine("Level: ${info.battery.levelPercent}% (${if (info.battery.isCharging) "Charging" else "Not charging"})")
    sb.appendLine("Temperature: ${info.battery.temperatureCelsius.getOrNull()?.let { "%.1f°C".format(it) } ?: na}")
    sb.appendLine("Health: ${info.battery.healthStatus.getOrNull().orNa()}")
    sb.appendLine()
    sb.appendLine("[Thermal]")
    sb.appendLine("Status: ${if (info.thermal.isThermalApiSupported) info.thermal.thermalStatus.name else na}")
    sb.appendLine()
    sb.appendLine("[Storage]")
    sb.appendLine("Available: ${UnitFormatter.formatGb(info.storage.availableBytes)} / ${UnitFormatter.formatGb(info.storage.totalBytes)}")

    if (scores != null) {
        sb.appendLine()
        sb.appendLine("[Performance Scores 0-100]")
        sb.appendLine("CPU: ${scores.cpuScore}  GPU: ${scores.gpuScore}  RAM: ${scores.ramScore}")
        sb.appendLine("Storage: ${scores.storageScore}  Thermal: ${scores.thermalScore}  Battery: ${scores.batteryScore}")
        sb.appendLine("Overall: ${scores.overallScore}")
    }

    if (recommendation != null) {
        sb.appendLine()
        sb.appendLine("[Recommended Free Fire Settings]")
        sb.appendLine("Profile: ${recommendation.profile.name} (${recommendation.profileConfidencePercent}% confidence)")
        sb.appendLine("Graphics: ${recommendation.graphicsQuality.value.name}")
        sb.appendLine("FPS: ${recommendation.frameRate.value.name}")
        sb.appendLine("Resolution: ${recommendation.resolution.value.name}")
        sb.appendLine("Shadow: ${recommendation.shadow.value.name}")
        sb.appendLine("Anti-Aliasing: ${recommendation.antiAliasing.value.name}")
        sb.appendLine("Texture: ${recommendation.textureQuality.value.name}")
        sb.appendLine("Effects: ${recommendation.effects.value.name}")
    }

    sb.appendLine()
    sb.appendLine("Note: values are read directly from Android APIs where possible. Any value marked")
    sb.appendLine("N/A means Android/this device does not expose it; it is never guessed.")
    return sb.toString()
}
