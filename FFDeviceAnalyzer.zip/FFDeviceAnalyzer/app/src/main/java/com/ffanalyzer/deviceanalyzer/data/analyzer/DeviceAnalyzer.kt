package com.ffanalyzer.deviceanalyzer.data.analyzer

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.util.DisplayMetrics
import android.view.Display
import android.view.WindowManager
import com.ffanalyzer.deviceanalyzer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Reads real, currently-available device information through public Android APIs.
 *
 * HARD RULE: every field this class cannot honestly obtain is returned as
 * [AvailableValue.Unavailable]. Nothing here is invented, guessed, or defaulted from a
 * device name lookup table.
 */
class DeviceAnalyzer(private val context: Context) {

    suspend fun analyze(): DeviceInfo = withContext(Dispatchers.Default) {
        DeviceInfo(
            system = readSystemInfo(),
            cpu = readCpuInfo(),
            gpu = readGpuInfo(),
            ram = readRamInfo(),
            storage = readStorageInfo(),
            display = readDisplayInfo(),
            battery = readBatteryInfo(),
            thermal = readThermalInfo(),
            network = readNetworkInfo(),
            timestampMillis = System.currentTimeMillis()
        )
    }

    // ---------- System ----------

    private fun readSystemInfo(): SystemInfo = SystemInfo(
        manufacturer = Build.MANUFACTURER ?: "Unknown",
        brand = Build.BRAND ?: "Unknown",
        model = Build.MODEL ?: "Unknown",
        device = Build.DEVICE ?: "Unknown",
        androidVersion = Build.VERSION.RELEASE ?: "Unknown",
        apiLevel = Build.VERSION.SDK_INT,
        buildId = Build.DISPLAY ?: "Unknown",
        securityPatch = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            AvailableValue.Measured(Build.VERSION.SECURITY_PATCH)
        } else AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED),
        // Android exposes no reliable public API to identify an OEM skin (MIUI/OneUI/ColorOS/...) version.
        uiFingerprint = AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)
    )

    // ---------- CPU ----------

    private fun readCpuInfo(): CpuInfo {
        val abis = Build.SUPPORTED_ABIS?.toList() ?: listOf(Build.CPU_ABI ?: "unknown")
        val coreCount = Runtime.getRuntime().availableProcessors()

        val currentFreqs = readPerCoreFrequencyFile(coreCount, "scaling_cur_freq")
        val maxFreqs = readPerCoreFrequencyFile(coreCount, "cpuinfo_max_freq")

        val cpuName = readCpuHardwareName()

        return CpuInfo(
            architecture = abis.firstOrNull() ?: "unknown",
            supportedAbis = abis,
            coreCount = coreCount,
            currentFrequenciesKhz = currentFreqs,
            maxFrequenciesKhz = maxFreqs,
            cpuName = cpuName
        )
    }

    /**
     * /sys/devices/system/cpu/cpuN/cpufreq/<file> is a best-effort, non-guaranteed sysfs path.
     * Many OEMs (especially on Android 10+) block read access for non-system apps — in that
     * case we correctly report Unavailable rather than fabricate numbers.
     */
    private fun readPerCoreFrequencyFile(coreCount: Int, fileName: String): AvailableValue<List<Long?>> {
        val results = mutableListOf<Long?>()
        var anySucceeded = false
        for (i in 0 until coreCount) {
            val path = "/sys/devices/system/cpu/cpu$i/cpufreq/$fileName"
            val value = try {
                val file = File(path)
                if (file.exists() && file.canRead()) {
                    BufferedReader(FileReader(file)).use { it.readLine() }?.trim()?.toLongOrNull()
                } else null
            } catch (_: Exception) {
                null
            }
            if (value != null) anySucceeded = true
            results.add(value)
        }
        return if (anySucceeded) AvailableValue.Measured(results)
        else AvailableValue.Unavailable(UnavailableReason.PERMISSION_DENIED)
    }

    private fun readCpuHardwareName(): AvailableValue<String> {
        return try {
            val file = File("/proc/cpuinfo")
            if (!file.exists() || !file.canRead()) {
                return AvailableValue.Unavailable(UnavailableReason.PERMISSION_DENIED)
            }
            val lines = file.readLines()
            val hardware = lines.firstOrNull { it.startsWith("Hardware", ignoreCase = true) }
                ?.substringAfter(":")?.trim()
            val modelName = lines.firstOrNull { it.startsWith("model name", ignoreCase = true) }
                ?.substringAfter(":")?.trim()
            val name = hardware ?: modelName
            if (name.isNullOrBlank()) AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)
            else AvailableValue.Measured(name)
        } catch (_: Exception) {
            AvailableValue.Unavailable(UnavailableReason.PERMISSION_DENIED)
        }
    }

    // ---------- GPU ----------

    /**
     * Queries GL_RENDERER/GL_VENDOR/GL_VERSION via a throwaway EGL context. This is the only
     * reliable, permission-free way to identify the GPU on stock Android; there is no
     * PackageManager/SystemProperties API for "GPU model".
     */
    private fun readGpuInfo(): GpuInfo {
        return try {
            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) return unavailableGpu()

            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) return unavailableGpu()

            val configAttribs = intArrayOf(
                EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_NONE
            )
            val configs = arrayOfNulls<EGLConfig>(1)
            val numConfigs = IntArray(1)
            EGL14.eglChooseConfig(display, configAttribs, 0, configs, 0, 1, numConfigs, 0)
            val config = configs[0] ?: return unavailableGpu()

            val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
            val eglContext: EGLContext = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)
                ?: return unavailableGpu()

            val surfaceAttribs = intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE)
            val surface: EGLSurface = EGL14.eglCreatePbufferSurface(display, config, surfaceAttribs, 0)
                ?: return unavailableGpu()

            EGL14.eglMakeCurrent(display, surface, surface, eglContext)

            val renderer = GLES20.glGetString(GLES20.GL_RENDERER)
            val vendor = GLES20.glGetString(GLES20.GL_VENDOR)
            val glVersionString = GLES20.glGetString(GLES20.GL_VERSION)

            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surface)
            EGL14.eglDestroyContext(display, eglContext)
            EGL14.eglTerminate(display)

            val vulkanSupported = context.packageManager.hasSystemFeature("android.hardware.vulkan.version")
            val vulkanVersion = if (vulkanSupported) {
                try {
                    val fi = context.packageManager.getSystemAvailableFeatures()
                        .firstOrNull { it.name == "android.hardware.vulkan.version" }
                    val raw = fi?.version ?: 0
                    if (raw > 0) {
                        val major = (raw shr 22) and 0x7F
                        val minor = (raw shr 12) and 0x3FF
                        AvailableValue.Measured("$major.$minor")
                    } else AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)
                } catch (_: Exception) {
                    AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)
                }
            } else AvailableValue.Unavailable(UnavailableReason.HARDWARE_ABSENT)

            GpuInfo(
                renderer = renderer?.let { AvailableValue.Measured(it) } ?: AvailableValue.Unavailable(),
                vendor = vendor?.let { AvailableValue.Measured(it) } ?: AvailableValue.Unavailable(),
                openGlEsVersion = glVersionString?.let { AvailableValue.Measured(it) } ?: AvailableValue.Unavailable(),
                vulkanSupported = AvailableValue.Measured(vulkanSupported),
                vulkanVersion = vulkanVersion
            )
        } catch (_: Exception) {
            unavailableGpu()
        }
    }

    private fun unavailableGpu() = GpuInfo(
        renderer = AvailableValue.Unavailable(),
        vendor = AvailableValue.Unavailable(),
        openGlEsVersion = AvailableValue.Unavailable(),
        vulkanSupported = AvailableValue.Unavailable(),
        vulkanVersion = AvailableValue.Unavailable()
    )

    // ---------- RAM ----------

    private fun readRamInfo(): RamInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val used = info.totalMem - info.availMem
        val usedPercent = if (info.totalMem > 0) (used.toFloat() / info.totalMem.toFloat()) * 100f else 0f
        return RamInfo(
            totalBytes = info.totalMem,
            availableBytes = info.availMem,
            usedBytes = used,
            usedPercent = usedPercent,
            isLowMemory = info.lowMemory,
            threshold = info.threshold
        )
    }

    // ---------- Storage ----------

    private fun readStorageInfo(): StorageInfo {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val total = stat.blockCountLong * stat.blockSizeLong
        val available = stat.availableBlocksLong * stat.blockSizeLong
        val used = total - available
        val usedPercent = if (total > 0) (used.toFloat() / total.toFloat()) * 100f else 0f
        return StorageInfo(
            totalBytes = total,
            availableBytes = available,
            usedBytes = used,
            usedPercent = usedPercent
        )
    }

    // ---------- Display ----------

    private fun readDisplayInfo(): DisplayInfo {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        val display: Display? = wm.defaultDisplay
        @Suppress("DEPRECATION")
        display?.getRealMetrics(metrics)

        val widthPx = metrics.widthPixels
        val heightPx = metrics.heightPixels
        val densityDpi = metrics.densityDpi

        val refreshRate: AvailableValue<Float> = display?.refreshRate
            ?.takeIf { it > 0f }
            ?.let { AvailableValue.Measured(it) }
            ?: AvailableValue.Unavailable()

        val supportedRates: AvailableValue<List<Float>> = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && display != null) {
                val modes = display.supportedModes.map { it.refreshRate }.distinct().sorted()
                if (modes.isNotEmpty()) AvailableValue.Measured(modes) else AvailableValue.Unavailable()
            } else AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)
        } catch (_: Exception) {
            AvailableValue.Unavailable()
        }

        val diagonalInches: AvailableValue<Double> = try {
            val widthInches = widthPx / metrics.xdpi.toDouble()
            val heightInches = heightPx / metrics.ydpi.toDouble()
            if (metrics.xdpi > 0 && metrics.ydpi > 0) {
                AvailableValue.Estimated(sqrt(widthInches * widthInches + heightInches * heightInches))
            } else AvailableValue.Unavailable()
        } catch (_: Exception) {
            AvailableValue.Unavailable()
        }

        val densityBucket = when {
            densityDpi <= DisplayMetrics.DENSITY_LOW -> "ldpi"
            densityDpi <= DisplayMetrics.DENSITY_MEDIUM -> "mdpi"
            densityDpi <= DisplayMetrics.DENSITY_HIGH -> "hdpi"
            densityDpi <= DisplayMetrics.DENSITY_XHIGH -> "xhdpi"
            densityDpi <= DisplayMetrics.DENSITY_XXHIGH -> "xxhdpi"
            else -> "xxxhdpi"
        }

        val gcd = gcd(widthPx, heightPx)
        val aspect = if (gcd != 0) "${widthPx / gcd}:${heightPx / gcd}" else "-"

        return DisplayInfo(
            widthPx = widthPx,
            heightPx = heightPx,
            densityDpi = densityDpi,
            densityBucket = densityBucket,
            refreshRateHz = refreshRate,
            supportedRefreshRates = supportedRates,
            diagonalInches = diagonalInches,
            aspectRatio = aspect
        )
    }

    private fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

    // ---------- Battery ----------

    private fun readBatteryInfo(): BatteryInfo {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val isCharging = bm.isCharging

        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val isPowerSave = pm.isPowerSaveMode

        // Detailed temp/health/voltage require a sticky broadcast (ACTION_BATTERY_CHANGED)
        val batteryIntent = context.registerReceiver(
            null,
            android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
        )

        val tempTenthsCelsius = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        val temperature: AvailableValue<Float> =
            if (tempTenthsCelsius != null && tempTenthsCelsius != Int.MIN_VALUE) {
                AvailableValue.Measured(tempTenthsCelsius / 10f)
            } else AvailableValue.Unavailable()

        val healthInt = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
        val health: AvailableValue<String> = when (healthInt) {
            BatteryManager.BATTERY_HEALTH_GOOD -> AvailableValue.Measured("battery_health_good")
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> AvailableValue.Measured("battery_health_overheat")
            BatteryManager.BATTERY_HEALTH_DEAD -> AvailableValue.Measured("battery_health_dead")
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> AvailableValue.Measured("battery_health_over_voltage")
            BatteryManager.BATTERY_HEALTH_COLD -> AvailableValue.Measured("battery_health_cold")
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> AvailableValue.Measured("battery_health_failure")
            else -> AvailableValue.Unavailable()
        }

        val plugInt = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)
        val plug: AvailableValue<String> = when (plugInt) {
            BatteryManager.BATTERY_PLUGGED_AC -> AvailableValue.Measured("plug_ac")
            BatteryManager.BATTERY_PLUGGED_USB -> AvailableValue.Measured("plug_usb")
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> AvailableValue.Measured("plug_wireless")
            else -> AvailableValue.Unavailable()
        }

        val voltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, Int.MIN_VALUE)
        val voltageValue: AvailableValue<Int> =
            if (voltage != null && voltage != Int.MIN_VALUE) AvailableValue.Measured(voltage)
            else AvailableValue.Unavailable()

        return BatteryInfo(
            levelPercent = level,
            isCharging = isCharging,
            chargePlug = plug,
            temperatureCelsius = temperature,
            healthStatus = health,
            isPowerSaveMode = isPowerSave,
            voltage = voltageValue
        )
    }

    // ---------- Thermal ----------

    private fun readThermalInfo(): ThermalInfo {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val status = when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NORMAL
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
                PowerManager.THERMAL_STATUS_CRITICAL -> ThermalLevel.CRITICAL
                PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalLevel.EMERGENCY
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.SHUTDOWN
                else -> ThermalLevel.UNKNOWN
            }
            val headroom: AvailableValue<Float> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val h = pm.getThermalHeadroom(10)
                    if (!h.isNaN()) AvailableValue.Measured(h) else AvailableValue.Unavailable()
                } catch (_: Exception) {
                    AvailableValue.Unavailable()
                }
            } else AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)

            ThermalInfo(thermalStatus = status, isThermalApiSupported = true, headroom = headroom)
        } else {
            // Below API 29 there is no public thermal status API.
            ThermalInfo(
                thermalStatus = ThermalLevel.UNKNOWN,
                isThermalApiSupported = false,
                headroom = AvailableValue.Unavailable(UnavailableReason.NOT_SUPPORTED)
            )
        }
    }

    // ---------- Network ----------

    private fun readNetworkInfo(): NetworkInfo {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val capabilities = network?.let { cm.getNetworkCapabilities(it) }

        val type = when {
            capabilities == null -> ConnectionType.NONE
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> ConnectionType.WIFI
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> ConnectionType.MOBILE_DATA
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> ConnectionType.ETHERNET
            else -> ConnectionType.UNKNOWN
        }

        val linkSpeed: AvailableValue<Int> = try {
            if (type == ConnectionType.WIFI) {
                val wifiManager = context.applicationContext
                    .getSystemService(Context.WIFI_SERVICE) as? android.net.wifi.WifiManager
                val speed = wifiManager?.connectionInfo?.linkSpeed
                if (speed != null && speed >= 0) AvailableValue.Measured(speed)
                else AvailableValue.Unavailable()
            } else AvailableValue.Unavailable(UnavailableReason.HARDWARE_ABSENT)
        } catch (_: Exception) {
            AvailableValue.Unavailable(UnavailableReason.PERMISSION_DENIED)
        }

        val mobileType: AvailableValue<String> = AvailableValue.Unavailable(UnavailableReason.PERMISSION_DENIED)

        return NetworkInfo(
            connectionType = type,
            wifiLinkSpeedMbps = linkSpeed,
            mobileNetworkType = mobileType,
            pingMillis = AvailableValue.Unavailable(UnavailableReason.REQUIRES_TEST_RUN)
        )
    }
}
