package com.ffanalyzer.deviceanalyzer.data.model

/**
 * Core honesty wrapper used across the entire app.
 *
 * Every single piece of device information the app shows MUST be wrapped in this type.
 * There is no "default fallback number". If Android does not expose a value on this
 * device/OS version, the UI is required to render [Unavailable] and show a localized
 * "Not available on this device/Android version" string instead of guessing.
 *
 * - [Measured]   -> value read directly from an Android API. reliable = true.
 * - [Estimated]  -> value derived/computed by our own analyzer (e.g. a benchmark score,
 *                   or a heuristic reading like "current CPU frequency" averaged over cores).
 *                   Must be visually marked as an estimate in the UI, never presented as
 *                   a raw system fact.
 * - [Unavailable]-> Android/OEM does not expose this on this device or API level.
 */
sealed class AvailableValue<out T> {
    data class Measured<T>(val value: T) : AvailableValue<T>()
    data class Estimated<T>(val value: T, val note: String? = null) : AvailableValue<T>()
    data class Unavailable(val reason: UnavailableReason = UnavailableReason.NOT_SUPPORTED) :
        AvailableValue<Nothing>()

    val isAvailable: Boolean get() = this !is Unavailable

    fun getOrNull(): T? = when (this) {
        is Measured -> value
        is Estimated -> value
        is Unavailable -> null
    }

    inline fun <R> map(transform: (T) -> R): AvailableValue<R> = when (this) {
        is Measured -> Measured(transform(value))
        is Estimated -> Estimated(transform(value), note)
        is Unavailable -> this
    }
}

enum class UnavailableReason {
    NOT_SUPPORTED,      // API level too low / hardware doesn't expose it
    PERMISSION_DENIED,  // user declined a permission this reading needs
    HARDWARE_ABSENT,    // e.g. no thermal sensor, no Vulkan support
    REQUIRES_TEST_RUN   // value only becomes known after user runs the performance test
}

fun <T> availableOrUnavailable(condition: Boolean, produce: () -> T): AvailableValue<T> =
    if (condition) AvailableValue.Measured(produce()) else AvailableValue.Unavailable()
