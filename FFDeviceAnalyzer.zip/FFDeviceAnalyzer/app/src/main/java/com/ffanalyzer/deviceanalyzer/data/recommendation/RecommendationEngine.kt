package com.ffanalyzer.deviceanalyzer.data.recommendation

import com.ffanalyzer.deviceanalyzer.data.model.*
import kotlin.math.roundToInt

/**
 * Rule-based Recommendation Engine (spec §4 + §14).
 *
 * Design notes:
 * - Version 1 is explicit, readable IF/THEN rules exactly as requested in the spec, BUT the
 *   final decision is a weighted score across factors rather than a single rule short-circuiting
 *   everything, so a device that's strong on GPU but weak on RAM still gets a sensible, blended
 *   recommendation instead of an all-or-nothing jump.
 * - [engineVersion] and the [Strategy] interface exist so a future ML-based strategy can be
 *   swapped in later without touching call sites (spec §14: "قابلًا للتطوير بحيث يمكن لاحقًا
 *   إضافة نموذج ML").
 * - Nothing here invents a setting the current game version doesn't support: callers pass in
 *   [GameCapabilities] describing what the detected game version actually exposes, and the
 *   engine marks a setting `availableInCurrentGameVersion = false` instead of recommending it.
 */
interface RecommendationStrategy {
    val engineVersion: String
    fun recommend(factors: RecommendationFactors, capabilities: GameCapabilities): RecommendationResult
}

/** What settings the detected game/version actually exposes (best-effort, from known public info). */
data class GameCapabilities(
    val supportsExtremeFrameRate: Boolean = true, // some old versions cap at High
    val supports90Hz: Boolean = true,
    val supports120HzOption: Boolean = false, // Free Fire caps in-game FPS slider regardless of panel Hz
    val supportsVulkanRenderer: Boolean = false
)

class RuleBasedRecommendationEngine : RecommendationStrategy {

    override val engineVersion: String = "rule-based-v1"

    override fun recommend(factors: RecommendationFactors, capabilities: GameCapabilities): RecommendationResult {
        val profile = decideProfile(factors)

        val graphics = decideGraphics(factors, profile)
        val frameRate = decideFrameRate(factors, profile, capabilities)
        val resolution = decideResolution(factors, profile)
        val shadow = decideShadow(factors, profile)
        val aa = decideAntiAliasing(factors, profile)
        val texture = decideTexture(factors, profile)
        val effects = decideEffects(factors, profile)

        val autoAdjust = factors.thermalStatus == ThermalLevel.MODERATE ||
            factors.thermalStatus == ThermalLevel.SEVERE ||
            factors.batteryLevelPercent < 20

        return RecommendationResult(
            profile = profile.first,
            profileConfidencePercent = profile.second,
            profileReasonKey = profile.third,
            graphicsQuality = graphics,
            frameRate = frameRate,
            resolution = resolution,
            shadow = shadow,
            antiAliasing = aa,
            textureQuality = texture,
            effects = effects,
            autoAdjustGraphicsRecommended = autoAdjust
        )
    }

    /**
     * Weighted profile decision. Each candidate profile accumulates a score from 0-100 based on
     * how well the device's factors match it; the highest-scoring profile wins. This avoids the
     * "single IF/ELSE staircase" trap the spec explicitly warns against (§14: "لا تعتمد على
     * قواعد ثابتة فقط").
     */
    private fun decideProfile(f: RecommendationFactors): Triple<PerformanceProfile, Int, String> {
        val scores = mutableMapOf<PerformanceProfile, Double>()

        // --- Rule examples from spec §14, expressed as weighted contributions ---
        // IF RAM >= 8GB AND GPU_SCORE >= 70 AND THERMAL_STATUS == NORMAL THEN Maximum FPS
        var maxFpsScore = 0.0
        if (f.ramTotalGb >= 8) maxFpsScore += 30
        if (f.gpuScore >= 70) maxFpsScore += 30
        if (f.cpuScore >= 65) maxFpsScore += 15
        if (f.thermalStatus == ThermalLevel.NORMAL) maxFpsScore += 15
        if (f.refreshRateHz >= 90f) maxFpsScore += 10
        scores[PerformanceProfile.MAXIMUM_FPS] = maxFpsScore

        // IF RAM <= 4GB OR GPU_SCORE < 40 THEN prioritize smooth/stable (Balanced leaning smooth)
        var balancedScore = 40.0 // balanced is the sensible default baseline
        if (f.overallScore in 40..75) balancedScore += 30
        if (f.thermalStatus == ThermalLevel.LIGHT || f.thermalStatus == ThermalLevel.MODERATE) balancedScore += 15
        scores[PerformanceProfile.BALANCED] = balancedScore

        var batterySaverScore = 0.0
        if (f.batteryLevelPercent < 20 && !f.isCharging) batterySaverScore += 60
        if (f.batteryLevelPercent < 35 && !f.isCharging) batterySaverScore += 20
        scores[PerformanceProfile.BATTERY_SAVER] = batterySaverScore

        // IF THERMAL_STATUS is HIGH THEN prioritize Low Heat profile
        var lowHeatScore = 0.0
        when (f.thermalStatus) {
            ThermalLevel.SEVERE -> lowHeatScore += 70
            ThermalLevel.CRITICAL, ThermalLevel.EMERGENCY, ThermalLevel.SHUTDOWN -> lowHeatScore += 95
            ThermalLevel.MODERATE -> lowHeatScore += 35
            else -> {}
        }
        scores[PerformanceProfile.LOW_HEAT] = lowHeatScore

        var visualScore = 0.0
        if (f.ramTotalGb >= 8) visualScore += 20
        if (f.gpuScore >= 80) visualScore += 35
        if (f.cpuScore >= 75) visualScore += 15
        if (f.thermalStatus == ThermalLevel.NORMAL) visualScore += 15
        if (f.refreshRateHz < 90f) visualScore += 10 // lower refresh rate: less benefit from chasing FPS, more from visuals
        scores[PerformanceProfile.BEST_VISUAL_QUALITY] = visualScore

        val winner = scores.maxByOrNull { it.value } ?: (PerformanceProfile.BALANCED to 50.0)
        val total = scores.values.sum().takeIf { it > 0 } ?: 1.0
        val confidence = ((winner.value / total) * 100 * scores.size / 3).roundToInt().coerceIn(35, 98)

        val reasonKey = when (winner.key) {
            PerformanceProfile.MAXIMUM_FPS -> "reason_profile_max_fps"
            PerformanceProfile.BALANCED -> "reason_profile_balanced"
            PerformanceProfile.BATTERY_SAVER -> "reason_profile_battery_saver"
            PerformanceProfile.LOW_HEAT -> "reason_profile_low_heat"
            PerformanceProfile.BEST_VISUAL_QUALITY -> "reason_profile_best_visual"
        }

        return Triple(winner.key, confidence, reasonKey)
    }

    private fun decideGraphics(f: RecommendationFactors, profile: Triple<PerformanceProfile, Int, String>): RecommendedSetting<GraphicsQuality> {
        val value = when (profile.first) {
            PerformanceProfile.MAXIMUM_FPS -> if (f.gpuScore >= 85) GraphicsQuality.HD else GraphicsQuality.SMOOTH
            PerformanceProfile.BEST_VISUAL_QUALITY -> if (f.gpuScore >= 90) GraphicsQuality.ULTRA_HD else GraphicsQuality.HD
            PerformanceProfile.BATTERY_SAVER, PerformanceProfile.LOW_HEAT -> GraphicsQuality.SMOOTH
            PerformanceProfile.BALANCED -> GraphicsQuality.BALANCED
        }
        val reason = when {
            profile.first == PerformanceProfile.MAXIMUM_FPS -> "reason_graphics_max_fps"
            profile.first == PerformanceProfile.BEST_VISUAL_QUALITY -> "reason_graphics_visual"
            profile.first == PerformanceProfile.LOW_HEAT || profile.first == PerformanceProfile.BATTERY_SAVER -> "reason_graphics_efficiency"
            else -> "reason_graphics_balanced"
        }
        return RecommendedSetting(value, reason)
    }

    private fun decideFrameRate(
        f: RecommendationFactors,
        profile: Triple<PerformanceProfile, Int, String>,
        cap: GameCapabilities
    ): RecommendedSetting<FrameRateOption> {
        var value = when {
            profile.first == PerformanceProfile.LOW_HEAT -> FrameRateOption.MEDIUM
            profile.first == PerformanceProfile.BATTERY_SAVER -> FrameRateOption.LOW
            f.cpuScore >= 80 && f.gpuScore >= 80 && f.refreshRateHz >= 120f -> FrameRateOption.EXTREME_120
            f.cpuScore >= 70 && f.gpuScore >= 70 && f.refreshRateHz >= 90f -> FrameRateOption.EXTREME_90
            f.cpuScore >= 60 && f.gpuScore >= 55 -> FrameRateOption.HIGH
            f.overallScore >= 40 -> FrameRateOption.MEDIUM
            else -> FrameRateOption.LOW
        }

        var availableInGame = true
        if (value == FrameRateOption.EXTREME_120 && !cap.supports120HzOption) {
            value = FrameRateOption.EXTREME_90
            availableInGame = cap.supports90Hz
        }
        if (value == FrameRateOption.EXTREME_90 && !cap.supportsExtremeFrameRate) {
            value = FrameRateOption.HIGH
        }

        val reasonKey = when {
            value == FrameRateOption.EXTREME_120 || value == FrameRateOption.EXTREME_90 -> "reason_fps_high_refresh"
            profile.first == PerformanceProfile.LOW_HEAT -> "reason_fps_thermal"
            profile.first == PerformanceProfile.BATTERY_SAVER -> "reason_fps_battery"
            else -> "reason_fps_balanced"
        }

        return RecommendedSetting(value, reasonKey, availableInCurrentGameVersion = availableInGame)
    }

    private fun decideResolution(f: RecommendationFactors, profile: Triple<PerformanceProfile, Int, String>): RecommendedSetting<ResolutionOption> {
        val value = when {
            profile.first == PerformanceProfile.BEST_VISUAL_QUALITY && f.gpuScore >= 85 -> ResolutionOption.ULTRA_HD_OPT
            profile.first == PerformanceProfile.MAXIMUM_FPS -> ResolutionOption.MEDIUM
            profile.first == PerformanceProfile.LOW_HEAT || profile.first == PerformanceProfile.BATTERY_SAVER -> ResolutionOption.LOW
            else -> ResolutionOption.MEDIUM
        }
        val reason = if (value == ResolutionOption.MEDIUM && profile.first == PerformanceProfile.MAXIMUM_FPS)
            "reason_resolution_fps_priority" else "reason_resolution_balanced"
        return RecommendedSetting(value, reason)
    }

    private fun decideShadow(f: RecommendationFactors, profile: Triple<PerformanceProfile, Int, String>): RecommendedSetting<ShadowOption> {
        val value = when {
            profile.first == PerformanceProfile.BEST_VISUAL_QUALITY && f.gpuScore >= 80 -> ShadowOption.HIGH
            profile.first == PerformanceProfile.BALANCED && f.gpuScore >= 60 -> ShadowOption.LOW
            else -> ShadowOption.OFF
        }
        return RecommendedSetting(value, "reason_shadow_gpu_load")
    }

    private fun decideAntiAliasing(f: RecommendationFactors, profile: Triple<PerformanceProfile, Int, String>): RecommendedSetting<AntiAliasingOption> {
        val value = if (profile.first == PerformanceProfile.BEST_VISUAL_QUALITY && f.gpuScore >= 85)
            AntiAliasingOption.ON else AntiAliasingOption.OFF
        return RecommendedSetting(value, "reason_aa_stability")
    }

    private fun decideTexture(f: RecommendationFactors, profile: Triple<PerformanceProfile, Int, String>): RecommendedSetting<TristateOption> {
        val value = when {
            f.ramTotalGb >= 8 && f.gpuScore >= 70 -> TristateOption.HIGH
            f.ramTotalGb >= 4 -> TristateOption.MEDIUM
            else -> TristateOption.LOW
        }
        return RecommendedSetting(value, "reason_texture_ram")
    }

    private fun decideEffects(f: RecommendationFactors, profile: Triple<PerformanceProfile, Int, String>): RecommendedSetting<TristateOption> {
        val value = when (profile.first) {
            PerformanceProfile.BEST_VISUAL_QUALITY -> TristateOption.HIGH
            PerformanceProfile.BALANCED -> TristateOption.MEDIUM
            else -> TristateOption.LOW
        }
        return RecommendedSetting(value, "reason_effects_profile")
    }
}
