package com.ffanalyzer.deviceanalyzer.data.repository

import android.content.Context
import com.ffanalyzer.deviceanalyzer.data.analyzer.DeviceAnalyzer
import com.ffanalyzer.deviceanalyzer.data.analyzer.GameAnalyzer
import com.ffanalyzer.deviceanalyzer.data.analyzer.PerformanceAnalyzer
import com.ffanalyzer.deviceanalyzer.data.analyzer.ThermalMonitor
import com.ffanalyzer.deviceanalyzer.data.model.*
import com.ffanalyzer.deviceanalyzer.data.recommendation.GameCapabilities
import com.ffanalyzer.deviceanalyzer.data.recommendation.RecommendationStrategy
import com.ffanalyzer.deviceanalyzer.data.recommendation.RuleBasedRecommendationEngine
import kotlinx.coroutines.flow.Flow

/**
 * Single entry point the ViewModels talk to. Keeps analyzers + engine wired together and
 * caches the last full analysis in memory only (Local-first, spec §11 — nothing is sent
 * anywhere and nothing is persisted to disk beyond optional user-triggered report sharing).
 */
class DeviceRepository(
    context: Context,
    private val recommendationStrategy: RecommendationStrategy = RuleBasedRecommendationEngine()
) {
    private val appContext = context.applicationContext

    private val deviceAnalyzer = DeviceAnalyzer(appContext)
    private val performanceAnalyzer = PerformanceAnalyzer(appContext)
    private val thermalMonitor = ThermalMonitor(appContext)
    private val gameAnalyzer = GameAnalyzer(appContext)

    var lastDeviceInfo: DeviceInfo? = null
        private set
    var lastPerformanceScores: PerformanceScores? = null
        private set
    var lastGames: List<GameInfo> = emptyList()
        private set

    suspend fun analyzeDevice(): DeviceInfo {
        val info = deviceAnalyzer.analyze()
        lastDeviceInfo = info
        return info
    }

    fun runPerformanceTest(deviceInfo: DeviceInfo): Flow<TestProgress> =
        performanceAnalyzer.runFullTest(deviceInfo)

    fun capturePerformanceResult(): PerformanceScores? {
        lastPerformanceScores = performanceAnalyzer.lastResult
        return lastPerformanceScores
    }

    fun observeThermal() = thermalMonitor.observe()

    suspend fun detectGames(): List<GameInfo> {
        val games = gameAnalyzer.detectAll()
        lastGames = games
        return games
    }

    fun buildRecommendation(
        deviceInfo: DeviceInfo,
        scores: PerformanceScores,
        game: GameInfo?
    ): RecommendationResult {
        val ramGb = deviceInfo.ram.totalBytes / (1024.0 * 1024.0 * 1024.0)
        val storageGb = deviceInfo.storage.availableBytes / (1024.0 * 1024.0 * 1024.0)
        val refreshRate = deviceInfo.display.refreshRateHz.getOrNull() ?: 60f

        val factors = RecommendationFactors(
            cpuScore = scores.cpuScore,
            gpuScore = scores.gpuScore,
            ramScore = scores.ramScore,
            ramTotalGb = ramGb,
            refreshRateHz = refreshRate,
            androidApiLevel = deviceInfo.system.apiLevel,
            thermalStatus = deviceInfo.thermal.thermalStatus,
            batteryLevelPercent = deviceInfo.battery.levelPercent,
            isCharging = deviceInfo.battery.isCharging,
            availableStorageGb = storageGb,
            overallScore = scores.overallScore
        )

        // Best-effort capability inference from the detected version; defaults stay conservative
        // (i.e. do not claim a setting exists) when the game isn't installed/detected.
        val capabilities = GameCapabilities(
            supportsExtremeFrameRate = true,
            supports90Hz = true,
            supports120HzOption = false,
            supportsVulkanRenderer = deviceInfo.gpu.vulkanSupported.getOrNull() == true
        )

        return recommendationStrategy.recommend(factors, capabilities)
    }
}
