package com.ffanalyzer.deviceanalyzer

import android.app.Application
import com.ffanalyzer.deviceanalyzer.data.repository.DeviceRepository

class FFDeviceAnalyzerApp : Application() {

    // Simple manual DI — single shared repository instance, no network/singletons beyond memory.
    lateinit var deviceRepository: DeviceRepository
        private set

    override fun onCreate() {
        super.onCreate()
        deviceRepository = DeviceRepository(this)
    }
}
