package com.ffanalyzer.deviceanalyzer.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.ffanalyzer.deviceanalyzer.data.model.*
import com.ffanalyzer.deviceanalyzer.data.repository.DeviceRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class UiLoadState {
    object Idle : UiLoadState()
    object Loading : UiLoadState()
    data class Error(val messageKey: String = "error_generic") : UiLoadState()
    object Success : UiLoadState()
}

/**
 * Shared, activity-scoped state so Home -> Analysis -> Results -> Device Info all see the
 * same single analysis snapshot, matching spec's "analyze once, use everywhere" flow.
 */
class AppViewModel(private val repository: DeviceRepository) : ViewModel() {

    private val _deviceInfo = MutableStateFlow<DeviceInfo?>(null)
    val deviceInfo: StateFlow<DeviceInfo?> = _deviceInfo.asStateFlow()

    private val _performanceScores = MutableStateFlow<PerformanceScores?>(null)
    val performanceScores: StateFlow<PerformanceScores?> = _performanceScores.asStateFlow()

    private val _testProgress = MutableStateFlow<TestProgress?>(null)
    val testProgress: StateFlow<TestProgress?> = _testProgress.asStateFlow()

    private val _games = MutableStateFlow<List<GameInfo>>(emptyList())
    val games: StateFlow<List<GameInfo>> = _games.asStateFlow()

    private val _selectedGame = MutableStateFlow<SupportedGame>(SupportedGame.FREE_FIRE)
    val selectedGame: StateFlow<SupportedGame> = _selectedGame.asStateFlow()

    private val _recommendation = MutableStateFlow<RecommendationResult?>(null)
    val recommendation: StateFlow<RecommendationResult?> = _recommendation.asStateFlow()

    private val _loadState = MutableStateFlow<UiLoadState>(UiLoadState.Idle)
    val loadState: StateFlow<UiLoadState> = _loadState.asStateFlow()

    fun selectGame(game: SupportedGame) {
        _selectedGame.value = game
        recomputeRecommendationIfPossible()
    }

    fun runFullAnalysis() {
        viewModelScope.launch {
            _loadState.value = UiLoadState.Loading
            try {
                val info = repository.analyzeDevice()
                _deviceInfo.value = info
                _games.value = repository.detectGames()

                repository.runPerformanceTest(info).collect { progress ->
                    _testProgress.value = progress
                }
                val scores = repository.capturePerformanceResult()
                _performanceScores.value = scores

                recomputeRecommendationIfPossible()
                _loadState.value = UiLoadState.Success
            } catch (e: Exception) {
                _loadState.value = UiLoadState.Error()
            }
        }
    }

    private fun recomputeRecommendationIfPossible() {
        val info = _deviceInfo.value ?: return
        val scores = _performanceScores.value ?: return
        val game = _games.value.firstOrNull { it.game == _selectedGame.value }
        _recommendation.value = repository.buildRecommendation(info, scores, game)
    }

    companion object {
        fun factory(repository: DeviceRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return AppViewModel(repository) as T
                }
            }
    }
}
