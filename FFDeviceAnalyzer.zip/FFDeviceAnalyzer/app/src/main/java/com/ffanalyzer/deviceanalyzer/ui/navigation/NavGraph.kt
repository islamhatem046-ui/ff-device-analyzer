package com.ffanalyzer.deviceanalyzer.ui.navigation

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Analysis : Screen("analysis")
    object Results : Screen("results")
    object DeviceInfo : Screen("device_info")
    object Performance : Screen("performance")
    object Thermal : Screen("thermal")
    object Report : Screen("report")
    object Privacy : Screen("privacy")
    object Settings : Screen("settings")
}
