package com.ffanalyzer.deviceanalyzer.ui.screens.privacy

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.ui.components.InfoCard

@Composable
fun PrivacyScreen() {
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.privacy_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Text(
                stringResource(R.string.privacy_local_first),
                style = MaterialTheme.typography.bodyLarge
            )
            Spacer(Modifier.height(20.dp))

            InfoCard(title = stringResource(R.string.privacy_what_we_read)) {
                PrivacyLine(stringResource(R.string.section_cpu), "Core count, architecture, and (when the OS allows it) frequency — to estimate raw processing power.")
                PrivacyLine(stringResource(R.string.section_gpu), "Renderer name and OpenGL/Vulkan capability — to know what graphics settings your device can render.")
                PrivacyLine(stringResource(R.string.section_ram), "Total/available memory — to size texture and effects recommendations.")
                PrivacyLine(stringResource(R.string.section_display), "Resolution and refresh rate — to recommend a matching FPS target.")
                PrivacyLine(stringResource(R.string.section_battery), "Level, temperature and charging state — to warn about heat/battery risk while gaming.")
                PrivacyLine(stringResource(R.string.section_network), "Connection type and, only if you run the optional test, latency — to give network-aware advice.")
                PrivacyLine("Free Fire / Free Fire MAX", "Package name and version, read only through Android's public app-listing API, never the game's files or memory.")
            }

            Spacer(Modifier.height(16.dp))
            InfoCard(title = stringResource(R.string.privacy_what_we_dont)) {
                Text(stringResource(R.string.privacy_dont_list), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun PrivacyLine(title: String, detail: String) {
    Column(Modifier.padding(vertical = 6.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(detail, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
