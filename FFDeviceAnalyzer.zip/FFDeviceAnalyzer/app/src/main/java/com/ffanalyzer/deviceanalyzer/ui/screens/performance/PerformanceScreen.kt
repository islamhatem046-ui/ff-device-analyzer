package com.ffanalyzer.deviceanalyzer.ui.screens.performance

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.components.*

@Composable
fun PerformanceScreen(viewModel: AppViewModel) {
    val scores by viewModel.performanceScores.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.performance_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            val s = scores
            if (s == null) {
                EmptyStateMessage(
                    title = stringResource(R.string.performance_title),
                    subtitle = stringResource(R.string.start_analysis)
                )
            } else {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    ScoreRing(s.overallScore, stringResource(R.string.performance_overall), size = 120.dp)
                }
                Spacer(Modifier.height(20.dp))
                InfoCard(title = "") {
                    LinearScoreBar(stringResource(R.string.stage_cpu), s.cpuScore)
                    LinearScoreBar(stringResource(R.string.stage_gpu), s.gpuScore)
                    LinearScoreBar(stringResource(R.string.stage_ram), s.ramScore)
                    LinearScoreBar(stringResource(R.string.stage_storage), s.storageScore)
                    LinearScoreBar(stringResource(R.string.stage_thermal), s.thermalScore)
                    LinearScoreBar(stringResource(R.string.stage_battery), s.batteryScore)
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    stringResource(R.string.ui_fps_note),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                val frame = s.uiFrameStats.getOrNull()
                if (frame != null) {
                    Spacer(Modifier.height(8.dp))
                    InfoCard(title = "") {
                        SpecRow(stringResource(R.string.ui_fps_current), "%.0f".format(frame.currentFps))
                        SpecRow(stringResource(R.string.ui_fps_average), "%.0f".format(frame.averageFps))
                        frame.onePercentLowFps?.let { SpecRow(stringResource(R.string.ui_fps_low1), "%.0f".format(it)) }
                        SpecRow(stringResource(R.string.ui_fps_frametime), "%.1f ms".format(frame.averageFrameTimeMs))
                        SpecRow(stringResource(R.string.ui_fps_stability), "%.0f%%".format(frame.stabilityPercent))
                    }
                }
            }
        }
    }
}
