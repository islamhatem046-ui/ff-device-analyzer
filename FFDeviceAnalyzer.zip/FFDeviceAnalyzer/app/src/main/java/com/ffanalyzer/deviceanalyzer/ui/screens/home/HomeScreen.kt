package com.ffanalyzer.deviceanalyzer.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.data.model.*
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.UiLoadState
import com.ffanalyzer.deviceanalyzer.ui.components.*
import com.ffanalyzer.deviceanalyzer.util.UnitFormatter

@Composable
fun HomeScreen(
    viewModel: AppViewModel,
    onStartAnalysis: () -> Unit,
    onOpenDeviceInfo: () -> Unit,
    onOpenPerformance: () -> Unit,
    onOpenThermal: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val scores by viewModel.performanceScores.collectAsState()
    val loadState by viewModel.loadState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.home_title), fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.nav_settings))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(
                stringResource(R.string.home_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(20.dp))

            if (deviceInfo == null || scores == null) {
                EmptyStateMessage(
                    title = stringResource(R.string.start_analysis),
                    subtitle = stringResource(R.string.home_subtitle)
                )
            } else {
                SummaryGrid(deviceInfo!!, scores!!)
            }

            Spacer(Modifier.height(20.dp))

            PrimaryActionButton(
                text = if (deviceInfo == null) stringResource(R.string.start_analysis)
                else stringResource(R.string.run_analysis_again),
                onClick = onStartAnalysis,
                enabled = loadState != UiLoadState.Loading
            )

            Spacer(Modifier.height(24.dp))

            QuickLinksRow(onOpenDeviceInfo, onOpenPerformance, onOpenThermal)
        }
    }
}

@Composable
private fun SummaryGrid(deviceInfo: DeviceInfo, scores: PerformanceScores) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        ScoreRing(scores.overallScore, stringResource(R.string.device_score), modifier = Modifier.weight(1f))
        ScoreRing(
            ((scores.cpuScore + scores.gpuScore) / 2),
            stringResource(R.string.gaming_score),
            modifier = Modifier.weight(1f)
        )
    }
    Spacer(Modifier.height(16.dp))
    InfoCard(title = "") {
        SpecRow(
            stringResource(R.string.thermal_status_label),
            thermalLabel(deviceInfo.thermal.thermalStatus)
        )
        SpecRow(stringResource(R.string.ram_usage_label), UnitFormatter.formatPercent(deviceInfo.ram.usedPercent))
        AvailableValueRow(
            stringResource(R.string.refresh_rate_label),
            deviceInfo.display.refreshRateHz,
            UnitFormatter::formatHz
        )
        AvailableValueRow(
            stringResource(R.string.battery_temp_label),
            deviceInfo.battery.temperatureCelsius,
            UnitFormatter::formatTemperature
        )
    }
}

@Composable
private fun AvailableValueRow(
    label: String,
    value: AvailableValue<Float>,
    format: (Float) -> String
) {
    val text = when (value) {
        is AvailableValue.Measured -> format(value.value)
        is AvailableValue.Estimated -> format(value.value) + " *"
        is AvailableValue.Unavailable -> stringResource(R.string.not_available)
    }
    SpecRow(label, text)
}

@Composable
private fun thermalLabel(level: ThermalLevel): String {
    val key = when (level) {
        ThermalLevel.NORMAL -> R.string.thermal_normal
        ThermalLevel.LIGHT -> R.string.thermal_light
        ThermalLevel.MODERATE -> R.string.thermal_moderate
        ThermalLevel.SEVERE -> R.string.thermal_severe
        ThermalLevel.CRITICAL -> R.string.thermal_critical
        ThermalLevel.EMERGENCY -> R.string.thermal_emergency
        ThermalLevel.SHUTDOWN -> R.string.thermal_shutdown
        ThermalLevel.UNKNOWN -> R.string.thermal_unknown
    }
    return stringResource(key)
}

@Composable
private fun QuickLinksRow(
    onOpenDeviceInfo: () -> Unit,
    onOpenPerformance: () -> Unit,
    onOpenThermal: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        QuickLinkCard(Icons.Default.PhoneAndroid, stringResource(R.string.nav_device), onOpenDeviceInfo, Modifier.weight(1f))
        QuickLinkCard(Icons.Default.Speed, stringResource(R.string.nav_performance), onOpenPerformance, Modifier.weight(1f))
        QuickLinkCard(Icons.Default.Thermostat, stringResource(R.string.nav_thermal), onOpenThermal, Modifier.weight(1f))
    }
}

@Composable
private fun QuickLinkCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            Modifier.padding(vertical = 16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.labelLarge)
        }
    }
}
