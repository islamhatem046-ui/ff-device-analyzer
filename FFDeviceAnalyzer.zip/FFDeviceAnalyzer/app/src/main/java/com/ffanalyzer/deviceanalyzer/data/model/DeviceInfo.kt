package com.ffanalyzer.deviceanalyzer.data.model

/** Snapshot of everything Android legally exposes about the device. */
data class DeviceInfo(
    val system: SystemInfo,
    val cpu: CpuInfo,
    val gpu: GpuInfo,
    val ram: RamInfo,
    val storage: StorageInfo,
    val display: DisplayInfo,
    val battery: BatteryInfo,
    val thermal: ThermalInfo,
    val network: NetworkInfo,
    val timestampMillis: Long
)

data class SystemInfo(
    val manufacturer: String,
    val brand: String,
    val model: String,
    val device: String,
    val androidVersion: String,
    val apiLevel: Int,
    val buildId: String,
    val securityPatch: AvailableValue<String>,
    val uiFingerprint: AvailableValue<String> // OEM skin can rarely be identified reliably
)

data class CpuInfo(
    val architecture: String,           // Build.SUPPORTED_ABIS[0] — always available
    val supportedAbis: List<String>,
    val coreCount: Int,                 // Runtime.availableProcessors() — always available
    val currentFrequenciesKhz: AvailableValue<List<Long?>>, // per-core, from /sys, may be partially null
    val maxFrequenciesKhz: AvailableValue<List<Long?>>,
    val cpuName: AvailableValue<String> // from /proc/cpuinfo "Hardware"/"model name", often absent on modern Android
)

data class GpuInfo(
    val renderer: AvailableValue<String>,     // GL_RENDERER via EGL query
    val vendor: AvailableValue<String>,       // GL_VENDOR
    val openGlEsVersion: AvailableValue<String>,
    val vulkanSupported: AvailableValue<Boolean>,
    val vulkanVersion: AvailableValue<String>
)

data class RamInfo(
    val totalBytes: Long,           // ActivityManager.MemoryInfo.totalMem
    val availableBytes: Long,
    val usedBytes: Long,
    val usedPercent: Float,
    val isLowMemory: Boolean,
    val threshold: Long
)

data class StorageInfo(
    val totalBytes: Long,
    val availableBytes: Long,
    val usedBytes: Long,
    val usedPercent: Float
)

data class DisplayInfo(
    val widthPx: Int,
    val heightPx: Int,
    val densityDpi: Int,
    val densityBucket: String,       // e.g. "xxhdpi"
    val refreshRateHz: AvailableValue<Float>,
    val supportedRefreshRates: AvailableValue<List<Float>>,
    val diagonalInches: AvailableValue<Double>,
    val aspectRatio: String
)

data class BatteryInfo(
    val levelPercent: Int,
    val isCharging: Boolean,
    val chargePlug: AvailableValue<String>, // AC / USB / Wireless
    val temperatureCelsius: AvailableValue<Float>,
    val healthStatus: AvailableValue<String>,
    val isPowerSaveMode: Boolean,
    val voltage: AvailableValue<Int>
)

data class ThermalInfo(
    val thermalStatus: ThermalLevel,     // from PowerManager.getCurrentThermalStatus (API 29+)
    val isThermalApiSupported: Boolean,
    val headroom: AvailableValue<Float>  // PowerManager.getThermalHeadroom (API 30+)
)

enum class ThermalLevel(val labelKey: String) {
    NORMAL("thermal_normal"),
    LIGHT("thermal_light"),
    MODERATE("thermal_moderate"),
    SEVERE("thermal_severe"),
    CRITICAL("thermal_critical"),
    EMERGENCY("thermal_emergency"),
    SHUTDOWN("thermal_shutdown"),
    UNKNOWN("thermal_unknown")
}

data class NetworkInfo(
    val connectionType: ConnectionType,
    val wifiLinkSpeedMbps: AvailableValue<Int>,
    val mobileNetworkType: AvailableValue<String>,
    val pingMillis: AvailableValue<Long> // only populated after an explicit, user-triggered test
)

enum class ConnectionType { WIFI, MOBILE_DATA, ETHERNET, NONE, UNKNOWN }
