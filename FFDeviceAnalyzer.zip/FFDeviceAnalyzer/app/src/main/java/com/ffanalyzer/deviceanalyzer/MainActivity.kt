package com.ffanalyzer.deviceanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.navigation.Screen
import com.ffanalyzer.deviceanalyzer.ui.screens.analysis.AnalysisScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.deviceinfo.DeviceInfoScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.home.HomeScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.performance.PerformanceScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.privacy.PrivacyScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.report.ReportScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.results.ResultsScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.settings.SettingsScreen
import com.ffanalyzer.deviceanalyzer.ui.screens.thermal.ThermalScreen
import com.ffanalyzer.deviceanalyzer.ui.theme.FFDeviceAnalyzerTheme

class MainActivity : ComponentActivity() {

    private val app by lazy { application as FFDeviceAnalyzerApp }

    private val viewModel: AppViewModel by viewModels {
        AppViewModel.factory(app.deviceRepository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FFDeviceAnalyzerTheme {
                Surface {
                    RootNavHost(viewModel = viewModel, repository = app.deviceRepository)
                }
            }
        }
    }
}

private data class BottomDestination(val screen: Screen, val icon: androidx.compose.ui.graphics.vector.ImageVector, val labelRes: Int)

@Composable
private fun RootNavHost(viewModel: AppViewModel, repository: com.ffanalyzer.deviceanalyzer.data.repository.DeviceRepository) {
    val navController = rememberNavController()

    val bottomDestinations = listOf(
        BottomDestination(Screen.Home, Icons.Default.Home, R.string.nav_home),
        BottomDestination(Screen.DeviceInfo, Icons.Default.PhoneAndroid, R.string.nav_device),
        BottomDestination(Screen.Performance, Icons.Default.Speed, R.string.nav_performance),
        BottomDestination(Screen.Thermal, Icons.Default.Thermostat, R.string.nav_thermal)
    )

    Scaffold(
        bottomBar = {
            val backStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = backStackEntry?.destination
            val showBottomBar = bottomDestinations.any { it.screen.route == currentRoute?.route }
            if (showBottomBar) {
                NavigationBar {
                    bottomDestinations.forEach { dest ->
                        val selected = currentRoute?.hierarchy?.any { it.route == dest.screen.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(dest.screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = null) },
                            label = { Text(stringResource(dest.labelRes)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            NavHost(navController = navController, startDestination = Screen.Home.route) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        onStartAnalysis = { navController.navigate(Screen.Analysis.route) },
                        onOpenDeviceInfo = { navController.navigate(Screen.DeviceInfo.route) },
                        onOpenPerformance = { navController.navigate(Screen.Performance.route) },
                        onOpenThermal = { navController.navigate(Screen.Thermal.route) },
                        onOpenSettings = { navController.navigate(Screen.Settings.route) }
                    )
                }
                composable(Screen.Analysis.route) {
                    AnalysisScreen(
                        viewModel = viewModel,
                        onFinished = {
                            navController.navigate(Screen.Results.route) {
                                popUpTo(Screen.Home.route)
                            }
                        }
                    )
                }
                composable(Screen.Results.route) {
                    ResultsScreen(
                        viewModel = viewModel,
                        onOpenReport = { navController.navigate(Screen.Report.route) }
                    )
                }
                composable(Screen.DeviceInfo.route) { DeviceInfoScreen(viewModel) }
                composable(Screen.Performance.route) { PerformanceScreen(viewModel) }
                composable(Screen.Thermal.route) { ThermalScreen(repository) }
                composable(Screen.Report.route) { ReportScreen(viewModel) }
                composable(Screen.Privacy.route) { PrivacyScreen() }
                composable(Screen.Settings.route) {
                    SettingsScreen(onOpenPrivacy = { navController.navigate(Screen.Privacy.route) })
                }
            }
        }
    }
}
