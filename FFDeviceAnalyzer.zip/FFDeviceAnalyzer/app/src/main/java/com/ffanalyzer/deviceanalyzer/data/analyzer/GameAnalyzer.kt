package com.ffanalyzer.deviceanalyzer.data.analyzer

import android.content.Context
import android.content.pm.PackageManager
import com.ffanalyzer.deviceanalyzer.data.model.AvailableValue
import com.ffanalyzer.deviceanalyzer.data.model.GameInfo
import com.ffanalyzer.deviceanalyzer.data.model.SupportedGame
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reads *only* public PackageManager metadata (package name, versionName/versionCode) for the
 * two supported games. This class never opens, reads, writes, or modifies any file that belongs
 * to the game, never injects code, and never touches game memory. It exists purely to tailor the
 * wording of recommendations to a version the user actually has installed.
 */
class GameAnalyzer(private val context: Context) {

    // Official package identifiers as published on Google Play.
    private val packageNames = mapOf(
        SupportedGame.FREE_FIRE to "com.dts.freefireth",
        SupportedGame.FREE_FIRE_MAX to "com.dts.freefiremax"
    )

    suspend fun detect(game: SupportedGame): GameInfo = withContext(Dispatchers.Default) {
        val packageName = packageNames.getValue(game)
        try {
            val pm = context.packageManager
            val packageInfo = pm.getPackageInfo(packageName, 0)
            val versionCode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
                packageInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                packageInfo.versionCode.toLong()
            }
            GameInfo(
                game = game,
                packageName = packageName,
                isInstalled = true,
                versionName = packageInfo.versionName?.let { AvailableValue.Measured(it) }
                    ?: AvailableValue.Unavailable(),
                versionCode = AvailableValue.Measured(versionCode)
            )
        } catch (_: PackageManager.NameNotFoundException) {
            GameInfo(
                game = game,
                packageName = packageName,
                isInstalled = false,
                versionName = AvailableValue.Unavailable(),
                versionCode = AvailableValue.Unavailable()
            )
        }
    }

    suspend fun detectAll(): List<GameInfo> = SupportedGame.values().map { detect(it) }
}
