package com.ffanalyzer.deviceanalyzer.ui.screens.results

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.data.model.*
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.components.*

@Composable
fun ResultsScreen(
    viewModel: AppViewModel,
    onOpenReport: () -> Unit
) {
    val recommendation by viewModel.recommendation.collectAsState()
    val games by viewModel.games.collectAsState()
    val selectedGame by viewModel.selectedGame.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.best_settings_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            GameSelector(games, selectedGame, onSelect = viewModel::selectGame)
            Spacer(Modifier.height(16.dp))

            val rec = recommendation
            if (rec == null) {
                EmptyStateMessage(
                    title = stringResource(R.string.best_settings_title),
                    subtitle = stringResource(R.string.start_analysis)
                )
            } else {
                ProfileCard(rec)
                Spacer(Modifier.height(16.dp))
                SettingRow(stringResource(R.string.setting_graphics), rec.graphicsQuality.value.name, rec.graphicsQuality.reasonKey, rec.graphicsQuality.availableInCurrentGameVersion)
                SettingRow(stringResource(R.string.setting_fps), rec.frameRate.value.name, rec.frameRate.reasonKey, rec.frameRate.availableInCurrentGameVersion)
                SettingRow(stringResource(R.string.setting_resolution), rec.resolution.value.name, rec.resolution.reasonKey, rec.resolution.availableInCurrentGameVersion)
                SettingRow(stringResource(R.string.setting_shadow), rec.shadow.value.name, rec.shadow.reasonKey, rec.shadow.availableInCurrentGameVersion)
                SettingRow(stringResource(R.string.setting_aa), rec.antiAliasing.value.name, rec.antiAliasing.reasonKey, rec.antiAliasing.availableInCurrentGameVersion)
                SettingRow(stringResource(R.string.setting_texture), rec.textureQuality.value.name, rec.textureQuality.reasonKey, rec.textureQuality.availableInCurrentGameVersion)
                SettingRow(stringResource(R.string.setting_effects), rec.effects.value.name, rec.effects.reasonKey, rec.effects.availableInCurrentGameVersion)

                if (rec.autoAdjustGraphicsRecommended) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        stringResource(R.string.auto_adjust_suggested),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }

                Spacer(Modifier.height(20.dp))
                PrimaryActionButton(text = stringResource(R.string.report_generate_button), onClick = onOpenReport)
            }
        }
    }
}

@Composable
private fun GameSelector(games: List<GameInfo>, selected: SupportedGame, onSelect: (SupportedGame) -> Unit) {
    Column {
        Text(stringResource(R.string.select_game_title), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SupportedGame.values().forEach { game ->
                val info = games.firstOrNull { it.game == game }
                FilterChip(
                    selected = selected == game,
                    onClick = { onSelect(game) },
                    label = {
                        Text(stringResource(if (game == SupportedGame.FREE_FIRE) R.string.game_free_fire else R.string.game_free_fire_max))
                    }
                )
                if (info != null && !info.isInstalled && selected == game) {
                    // handled below in a note; chip stays simple
                }
            }
        }
        val currentInfo = games.firstOrNull { it.game == selected }
        if (currentInfo != null && !currentInfo.isInstalled) {
            Spacer(Modifier.height(6.dp))
            Text(
                stringResource(R.string.game_not_installed),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else if (currentInfo != null) {
            Spacer(Modifier.height(6.dp))
            val versionText = currentInfo.versionName.getOrNull() ?: stringResource(R.string.not_available)
            Text(
                "${stringResource(R.string.game_version_label)}: $versionText",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ProfileCard(rec: RecommendationResult) {
    InfoCard(title = stringResource(R.string.recommended_profile)) {
        Text(
            stringResource(profileLabelRes(rec.profile)),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            "${stringResource(R.string.confidence_label)}: ${rec.profileConfidencePercent}%",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        Text(stringResource(reasonRes(rec.profileReasonKey)), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun SettingRow(label: String, valueName: String, reasonKey: String, availableInGame: Boolean) {
    InfoCard(title = label, modifier = Modifier.padding(top = 10.dp)) {
        Text(valueName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            stringResource(reasonRes(reasonKey)),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (!availableInGame) {
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.not_available_in_game_version),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

private fun profileLabelRes(profile: PerformanceProfile): Int = when (profile) {
    PerformanceProfile.MAXIMUM_FPS -> R.string.profile_max_fps
    PerformanceProfile.BALANCED -> R.string.profile_balanced
    PerformanceProfile.BATTERY_SAVER -> R.string.profile_battery_saver
    PerformanceProfile.LOW_HEAT -> R.string.profile_low_heat
    PerformanceProfile.BEST_VISUAL_QUALITY -> R.string.profile_best_visual
}

/** Maps a RecommendationEngine reason key (a string constant) to its localized string resource. */
private fun reasonRes(key: String): Int = when (key) {
    "reason_profile_max_fps" -> R.string.reason_profile_max_fps
    "reason_profile_balanced" -> R.string.reason_profile_balanced
    "reason_profile_battery_saver" -> R.string.reason_profile_battery_saver
    "reason_profile_low_heat" -> R.string.reason_profile_low_heat
    "reason_profile_best_visual" -> R.string.reason_profile_best_visual
    "reason_fps_high_refresh" -> R.string.reason_fps_high_refresh
    "reason_fps_thermal" -> R.string.reason_fps_thermal
    "reason_fps_battery" -> R.string.reason_fps_battery
    "reason_fps_balanced" -> R.string.reason_fps_balanced
    "reason_graphics_max_fps" -> R.string.reason_graphics_max_fps
    "reason_graphics_visual" -> R.string.reason_graphics_visual
    "reason_graphics_efficiency" -> R.string.reason_graphics_efficiency
    "reason_graphics_balanced" -> R.string.reason_graphics_balanced
    "reason_resolution_fps_priority" -> R.string.reason_resolution_fps_priority
    "reason_resolution_balanced" -> R.string.reason_resolution_balanced
    "reason_shadow_gpu_load" -> R.string.reason_shadow_gpu_load
    "reason_aa_stability" -> R.string.reason_aa_stability
    "reason_texture_ram" -> R.string.reason_texture_ram
    "reason_effects_profile" -> R.string.reason_effects_profile
    else -> R.string.not_available
}
