package com.ffanalyzer.deviceanalyzer.data.analyzer

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.ffanalyzer.deviceanalyzer.data.model.AvailableValue
import com.ffanalyzer.deviceanalyzer.data.model.ThermalLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class ThermalSnapshot(
    val status: ThermalLevel,
    val isApiSupported: Boolean,
    val batteryTempCelsius: AvailableValue<Float>,
    val headroom: AvailableValue<Float>
)

/**
 * Live thermal readings for the "Thermal Monitor" screen (spec §6).
 * Uses PowerManager's official thermal-status listener when available (API 29+),
 * and falls back to a slow poll of battery temperature only, honestly marking
 * thermal status as Unknown/unsupported below API 29.
 */
class ThermalMonitor(private val context: Context) {

    fun observe(): Flow<ThermalSnapshot> = callbackFlow {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager

        fun currentBatteryTemp(): AvailableValue<Float> {
            val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
            return if (tenths != null && tenths != Int.MIN_VALUE) AvailableValue.Measured(tenths / 10f)
            else AvailableValue.Unavailable()
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val listener = PowerManager.OnThermalStatusChangedListener { status ->
                val level = mapStatus(status)
                val headroom: AvailableValue<Float> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val h = pm.getThermalHeadroom(10)
                        if (!h.isNaN()) AvailableValue.Measured(h) else AvailableValue.Unavailable()
                    } catch (_: Exception) {
                        AvailableValue.Unavailable()
                    }
                } else AvailableValue.Unavailable()

                trySend(ThermalSnapshot(level, true, currentBatteryTemp(), headroom))
            }
            pm.addThermalStatusListener(listener)
            // Emit an initial snapshot immediately
            trySend(
                ThermalSnapshot(
                    mapStatus(pm.currentThermalStatus), true, currentBatteryTemp(),
                    AvailableValue.Unavailable()
                )
            )
            awaitClose { pm.removeThermalStatusListener(listener) }
        } else {
            // No thermal-status API pre-Q: poll battery temperature only, every 3s, honestly
            // report the thermal *status* itself as unsupported/unknown.
            // callbackFlow's own scope (ProducerScope is a CoroutineScope) is used here —
            // no GlobalScope needed, and the loop is cancelled automatically when the
            // collector goes away because awaitClose cancels this producer scope's children.
            val job = launch {
                while (isActive) {
                    trySend(
                        ThermalSnapshot(
                            ThermalLevel.UNKNOWN, false, currentBatteryTemp(),
                            AvailableValue.Unavailable()
                        )
                    )
                    delay(3000)
                }
            }
            awaitClose { job.cancel() }
        }
    }

    private fun mapStatus(status: Int): ThermalLevel = when (status) {
        PowerManager.THERMAL_STATUS_NONE -> ThermalLevel.NORMAL
        PowerManager.THERMAL_STATUS_LIGHT -> ThermalLevel.LIGHT
        PowerManager.THERMAL_STATUS_MODERATE -> ThermalLevel.MODERATE
        PowerManager.THERMAL_STATUS_SEVERE -> ThermalLevel.SEVERE
        PowerManager.THERMAL_STATUS_CRITICAL -> ThermalLevel.CRITICAL
        PowerManager.THERMAL_STATUS_EMERGENCY -> ThermalLevel.EMERGENCY
        PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalLevel.SHUTDOWN
        else -> ThermalLevel.UNKNOWN
    }
}
