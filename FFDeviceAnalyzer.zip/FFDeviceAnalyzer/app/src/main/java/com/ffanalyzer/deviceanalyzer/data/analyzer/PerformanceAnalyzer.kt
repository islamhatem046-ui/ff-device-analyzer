package com.ffanalyzer.deviceanalyzer.data.analyzer

import android.content.Context
import android.os.Build
import android.os.PowerManager
import com.ffanalyzer.deviceanalyzer.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Runs short (a few seconds each), local, non-destructive micro-benchmarks to produce
 * 0-100 scores per subsystem. Every stage checks thermal status before/after running and
 * aborts the remaining stages early if the device is already SEVERE or worse — per spec §2.
 *
 * These are *local proxy benchmarks*, not the game engine itself. UI frame stats are labelled
 * clearly as the app's own UI performance, never as "Free Fire FPS".
 */
class PerformanceAnalyzer(private val context: Context) {

    private val powerManager by lazy { context.getSystemService(Context.POWER_SERVICE) as PowerManager }

    fun runFullTest(deviceInfo: DeviceInfo): Flow<TestProgress> = flow {
        var stopped = false

        emit(TestProgress(TestStage.CPU, 0, 0))
        val cpuScore = if (!stopped) runCpuTest { p -> } else 0
        emit(TestProgress(TestStage.CPU, 100, 15))
        stopped = stopped || isOverheating()

        emit(TestProgress(TestStage.GPU, 0, 20))
        val gpuScore = if (!stopped) runGpuProxyTest() else 0
        emit(TestProgress(TestStage.GPU, 100, 35))
        stopped = stopped || isOverheating()

        emit(TestProgress(TestStage.RAM, 0, 40, stopped))
        val ramScore = if (!stopped) runRamTest(deviceInfo) else scoreFromRamStatic(deviceInfo)
        emit(TestProgress(TestStage.RAM, 100, 55, stopped))
        stopped = stopped || isOverheating()

        emit(TestProgress(TestStage.STORAGE, 0, 60, stopped))
        val storageScore = if (!stopped) runStorageTest() else 50
        emit(TestProgress(TestStage.STORAGE, 100, 75, stopped))

        emit(TestProgress(TestStage.THERMAL, 0, 80, stopped))
        val thermalScore = scoreFromThermal(deviceInfo.thermal)
        emit(TestProgress(TestStage.THERMAL, 100, 88, stopped))

        emit(TestProgress(TestStage.BATTERY, 0, 90, stopped))
        val batteryScore = scoreFromBattery(deviceInfo.battery)
        emit(TestProgress(TestStage.BATTERY, 100, 96, stopped))

        this@PerformanceAnalyzer.lastResult = PerformanceScores(
            cpuScore = cpuScore,
            gpuScore = gpuScore,
            ramScore = ramScore,
            storageScore = storageScore,
            thermalScore = thermalScore,
            batteryScore = batteryScore,
            overallScore = weightedOverall(cpuScore, gpuScore, ramScore, storageScore, thermalScore, batteryScore),
            testWasStoppedEarlyDueToHeat = stopped,
            uiFrameStats = AvailableValue.Unavailable(UnavailableReason.REQUIRES_TEST_RUN)
        )

        emit(TestProgress(TestStage.DONE, 100, 100, stopped))
    }

    var lastResult: PerformanceScores? = null
        private set

    private fun isOverheating(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            return powerManager.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
        }
        return false
    }

    /** Short, bounded integer/float math workload across available cores (~1.5s). */
    private suspend fun runCpuTest(onProgress: (Int) -> Unit): Int = withContext(Dispatchers.Default) {
        val cores = Runtime.getRuntime().availableProcessors()
        val startTime = System.nanoTime()
        var operations = 0L
        val durationNanos = 1_500_000_000L // hard cap: 1.5 seconds, never long-running

        var acc = 1.0000001
        while (System.nanoTime() - startTime < durationNanos) {
            repeat(50_000) {
                acc = (acc * 1.0000001) + Math.sqrt(acc)
                operations++
            }
            if (acc.isInfinite()) acc = 1.0 // guard against overflow, keep loop cheap
        }
        val elapsedMs = (System.nanoTime() - startTime) / 1_000_000.0
        val opsPerMsPerCore = (operations / elapsedMs) / max(1, cores)

        // Normalize against a reasonable modern-midrange reference point.
        val reference = 4000.0
        val score = ((opsPerMsPerCore / reference) * 70 + cores * 3.75).roundToInt()
        min(100, max(5, score))
    }

    /** Bounded off-screen pixel/matrix workload proxy — not a real GPU benchmark suite. */
    private suspend fun runGpuProxyTest(): Int = withContext(Dispatchers.Default) {
        val size = 256
        val a = FloatArray(size) { Random.nextFloat() }
        val b = FloatArray(size) { Random.nextFloat() }
        val start = System.nanoTime()
        var iterations = 0
        val durationNanos = 1_200_000_000L
        var sum = 0f
        while (System.nanoTime() - start < durationNanos) {
            for (i in 0 until size) {
                sum += a[i] * b[i] + (a[i] - b[i])
            }
            iterations++
            if (sum.isInfinite() || sum.isNaN()) sum = 0f
        }
        val elapsedMs = (System.nanoTime() - start) / 1_000_000.0
        val throughput = iterations / elapsedMs
        val score = (throughput * 2.2).roundToInt()
        min(100, max(10, score))
    }

    private suspend fun runRamTest(deviceInfo: DeviceInfo): Int = withContext(Dispatchers.Default) {
        val sizeMb = min(64, max(8, (deviceInfo.ram.availableBytes / (1024 * 1024) / 20).toInt()))
        val buffer = ByteArray(sizeMb * 1024 * 1024)
        val start = System.nanoTime()
        for (i in buffer.indices step 4096) {
            buffer[i] = (i % 128).toByte()
        }
        var checksum = 0L
        for (i in buffer.indices step 4096) {
            checksum += buffer[i]
        }
        val elapsedMs = max(1.0, (System.nanoTime() - start) / 1_000_000.0)
        val mbPerSecProxy = sizeMb / (elapsedMs / 1000.0)

        val capacityScore = scoreFromRamStatic(deviceInfo)
        val speedScore = min(100, (mbPerSecProxy / 8).roundToInt())
        if (checksum == Long.MIN_VALUE) return@withContext 0 // unreachable, keeps checksum "used"
        ((capacityScore * 0.6) + (speedScore * 0.4)).roundToInt().coerceIn(5, 100)
    }

    private fun scoreFromRamStatic(deviceInfo: DeviceInfo): Int {
        val totalGb = deviceInfo.ram.totalBytes / (1024.0 * 1024.0 * 1024.0)
        return when {
            totalGb >= 12 -> 95
            totalGb >= 8 -> 82
            totalGb >= 6 -> 68
            totalGb >= 4 -> 50
            totalGb >= 3 -> 35
            else -> 20
        }
    }

    private suspend fun runStorageTest(): Int = withContext(Dispatchers.IO) {
        try {
            val testFile = File(context.cacheDir, "ff_storage_bench.tmp")
            val data = ByteArray(4 * 1024 * 1024) { 1 } // 4MB, deleted immediately after
            val writeStart = System.nanoTime()
            testFile.writeBytes(data)
            val writeMs = max(1.0, (System.nanoTime() - writeStart) / 1_000_000.0)

            val readStart = System.nanoTime()
            testFile.readBytes()
            val readMs = max(1.0, (System.nanoTime() - readStart) / 1_000_000.0)

            testFile.delete()

            val writeSpeedMbps = 4.0 / (writeMs / 1000.0)
            val readSpeedMbps = 4.0 / (readMs / 1000.0)
            val combined = (writeSpeedMbps * 0.4 + readSpeedMbps * 0.6)
            min(100, max(10, (combined * 0.6).roundToInt()))
        } catch (_: Exception) {
            50 // neutral score if the sandboxed write/read fails; not claimed as measured elsewhere
        }
    }

    private fun scoreFromThermal(thermal: ThermalInfo): Int = when (thermal.thermalStatus) {
        ThermalLevel.NORMAL -> 100
        ThermalLevel.LIGHT -> 80
        ThermalLevel.MODERATE -> 60
        ThermalLevel.SEVERE -> 35
        ThermalLevel.CRITICAL -> 15
        ThermalLevel.EMERGENCY, ThermalLevel.SHUTDOWN -> 5
        ThermalLevel.UNKNOWN -> 70 // neutral-leaning-good default when the API isn't supported (API < 29)
    }

    private fun scoreFromBattery(battery: BatteryInfo): Int {
        var score = when {
            battery.levelPercent >= 60 -> 90
            battery.levelPercent >= 30 -> 70
            battery.levelPercent >= 15 -> 45
            else -> 20
        }
        if (battery.isCharging) score = min(100, score + 10)
        if (battery.isPowerSaveMode) score = max(0, score - 15)
        return score
    }

    private fun weightedOverall(
        cpu: Int, gpu: Int, ram: Int, storage: Int, thermal: Int, battery: Int
    ): Int {
        // Weighted for gaming relevance: CPU/GPU/RAM matter most for Free Fire performance.
        val weighted = cpu * 0.28 + gpu * 0.30 + ram * 0.20 + storage * 0.07 +
            thermal * 0.10 + battery * 0.05
        return weighted.roundToInt().coerceIn(0, 100)
    }
}
