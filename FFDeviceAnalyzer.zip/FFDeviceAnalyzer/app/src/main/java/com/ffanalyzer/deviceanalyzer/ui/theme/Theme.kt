package com.ffanalyzer.deviceanalyzer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    background = GraphiteBlack,
    surface = GraphitePanel,
    surfaceVariant = GraphiteCard,
    primary = AccentOrange,
    onPrimary = GraphiteBlack,
    secondary = AccentTeal,
    onSecondary = GraphiteBlack,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = GraphiteBorder,
    error = StatusRed
)

private val LightColors = lightColorScheme(
    background = LightBackground,
    surface = LightSurface,
    surfaceVariant = LightCard,
    primary = AccentOrangeDim,
    onPrimary = LightSurface,
    secondary = AccentTealDim,
    onSecondary = LightSurface,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight,
    onSurfaceVariant = TextSecondaryLight,
    outline = Color(0xFFD7DCE5),
    error = StatusRed
)

@Composable
fun FFDeviceAnalyzerTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}
