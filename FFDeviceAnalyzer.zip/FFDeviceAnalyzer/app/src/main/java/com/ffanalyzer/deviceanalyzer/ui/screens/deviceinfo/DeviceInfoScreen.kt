package com.ffanalyzer.deviceanalyzer.ui.screens.deviceinfo

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.data.model.*
import com.ffanalyzer.deviceanalyzer.ui.AppViewModel
import com.ffanalyzer.deviceanalyzer.ui.components.EmptyStateMessage
import com.ffanalyzer.deviceanalyzer.ui.components.InfoCard
import com.ffanalyzer.deviceanalyzer.ui.components.SpecRow
import com.ffanalyzer.deviceanalyzer.util.UnitFormatter
import com.ffanalyzer.deviceanalyzer.util.buildDeviceReportText

@Composable
fun DeviceInfoScreen(viewModel: AppViewModel) {
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val clipboard = LocalClipboardManager.current
    val notAvailable = stringResource(R.string.not_available)
    val yes = stringResource(R.string.yes)
    val no = stringResource(R.string.no)

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.device_info_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        val info = deviceInfo
        if (info == null) {
            Box(Modifier.padding(padding).fillMaxSize()) {
                EmptyStateMessage(
                    title = stringResource(R.string.device_info_title),
                    subtitle = stringResource(R.string.start_analysis)
                )
            }
            return@Scaffold
        }

        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            InfoCard(title = stringResource(R.string.section_android)) {
                SpecRow(stringResource(R.string.spec_manufacturer), info.system.manufacturer)
                SpecRow(stringResource(R.string.spec_model), info.system.model)
                SpecRow(stringResource(R.string.spec_android_version), info.system.androidVersion)
                SpecRow(stringResource(R.string.spec_api_level), info.system.apiLevel.toString())
                SpecRow(stringResource(R.string.spec_security_patch), info.system.securityPatch.getOrNull() ?: notAvailable)
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_cpu)) {
                SpecRow(stringResource(R.string.spec_architecture), info.cpu.architecture)
                SpecRow(stringResource(R.string.spec_core_count), info.cpu.coreCount.toString())
                SpecRow(stringResource(R.string.spec_cpu_name), info.cpu.cpuName.getOrNull() ?: notAvailable)
                val curFreq = info.cpu.currentFrequenciesKhz.getOrNull()?.filterNotNull()?.takeIf { it.isNotEmpty() }?.average()
                SpecRow(
                    stringResource(R.string.spec_current_freq),
                    curFreq?.let { UnitFormatter.formatMhz(it.toLong()) } ?: notAvailable
                )
                val maxFreq = info.cpu.maxFrequenciesKhz.getOrNull()?.filterNotNull()?.maxOrNull()
                SpecRow(
                    stringResource(R.string.spec_max_freq),
                    maxFreq?.let { UnitFormatter.formatMhz(it) } ?: notAvailable
                )
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_gpu)) {
                SpecRow(stringResource(R.string.spec_gpu_renderer), info.gpu.renderer.getOrNull() ?: notAvailable)
                SpecRow(stringResource(R.string.spec_gpu_vendor), info.gpu.vendor.getOrNull() ?: notAvailable)
                SpecRow(stringResource(R.string.spec_opengl), info.gpu.openGlEsVersion.getOrNull() ?: notAvailable)
                SpecRow(
                    stringResource(R.string.spec_vulkan),
                    info.gpu.vulkanSupported.getOrNull()?.let { if (it) yes else no } ?: notAvailable
                )
                SpecRow(stringResource(R.string.spec_vulkan_version), info.gpu.vulkanVersion.getOrNull() ?: notAvailable)
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_ram)) {
                SpecRow(stringResource(R.string.spec_ram_total), UnitFormatter.formatGb(info.ram.totalBytes))
                SpecRow(stringResource(R.string.spec_ram_available), UnitFormatter.formatGb(info.ram.availableBytes))
                SpecRow(stringResource(R.string.spec_ram_used), UnitFormatter.formatGb(info.ram.usedBytes))
                SpecRow(stringResource(R.string.spec_ram_percent), UnitFormatter.formatPercent(info.ram.usedPercent))
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_storage)) {
                SpecRow(stringResource(R.string.spec_storage_total), UnitFormatter.formatGb(info.storage.totalBytes))
                SpecRow(stringResource(R.string.spec_storage_available), UnitFormatter.formatGb(info.storage.availableBytes))
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_display)) {
                SpecRow(stringResource(R.string.spec_resolution), "${info.display.widthPx} x ${info.display.heightPx}")
                SpecRow(stringResource(R.string.spec_density), "${info.display.densityDpi} (${info.display.densityBucket})")
                SpecRow(stringResource(R.string.spec_refresh_rate), info.display.refreshRateHz.getOrNull()?.let { UnitFormatter.formatHz(it) } ?: notAvailable)
                SpecRow(
                    stringResource(R.string.spec_supported_rates),
                    info.display.supportedRefreshRates.getOrNull()?.joinToString(", ") { "${it.toInt()}Hz" } ?: notAvailable
                )
                SpecRow(
                    stringResource(R.string.spec_screen_size),
                    info.display.diagonalInches.getOrNull()?.let { "%.1f\" (${stringResource(R.string.estimated_marker)})".format(it) } ?: notAvailable
                )
                SpecRow(stringResource(R.string.spec_aspect_ratio), info.display.aspectRatio)
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_battery)) {
                SpecRow(stringResource(R.string.spec_battery_level), "${info.battery.levelPercent}%")
                SpecRow(stringResource(R.string.spec_charging_state), if (info.battery.isCharging) yes else no)
                SpecRow(
                    stringResource(R.string.spec_battery_temp),
                    info.battery.temperatureCelsius.getOrNull()?.let { UnitFormatter.formatTemperature(it) } ?: notAvailable
                )
                SpecRow(stringResource(R.string.spec_battery_health), info.battery.healthStatus.getOrNull() ?: notAvailable)
                SpecRow(stringResource(R.string.spec_power_save), if (info.battery.isPowerSaveMode) yes else no)
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_thermal)) {
                SpecRow(
                    stringResource(R.string.spec_thermal_status),
                    if (info.thermal.isThermalApiSupported) info.thermal.thermalStatus.name else notAvailable
                )
            }
            Spacer(Modifier.height(12.dp))

            InfoCard(title = stringResource(R.string.section_network)) {
                SpecRow(stringResource(R.string.spec_connection_type), info.network.connectionType.name)
                SpecRow(stringResource(R.string.spec_wifi_speed), info.network.wifiLinkSpeedMbps.getOrNull()?.let { "$it Mbps" } ?: notAvailable)
                SpecRow(stringResource(R.string.spec_ping), info.network.pingMillis.getOrNull()?.let { "$it ms" } ?: notAvailable)
            }

            Spacer(Modifier.height(20.dp))
            OutlinedButton(
                onClick = { clipboard.setText(AnnotatedString(buildDeviceReportText(info, null, null))) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.copy_report))
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
