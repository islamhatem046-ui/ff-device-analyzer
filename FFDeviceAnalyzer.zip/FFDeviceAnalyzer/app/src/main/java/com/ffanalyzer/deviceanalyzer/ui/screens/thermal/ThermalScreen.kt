package com.ffanalyzer.deviceanalyzer.ui.screens.thermal

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.data.analyzer.ThermalSnapshot
import com.ffanalyzer.deviceanalyzer.data.model.ThermalLevel
import com.ffanalyzer.deviceanalyzer.data.repository.DeviceRepository
import com.ffanalyzer.deviceanalyzer.ui.components.InfoCard
import com.ffanalyzer.deviceanalyzer.ui.components.SpecRow
import com.ffanalyzer.deviceanalyzer.ui.components.StatusDot
import com.ffanalyzer.deviceanalyzer.ui.components.StatusDotLevel
import com.ffanalyzer.deviceanalyzer.util.UnitFormatter

@Composable
fun ThermalScreen(repository: DeviceRepository) {
    val snapshot by repository.observeThermal().collectAsState(initial = null)

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.thermal_monitor_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            val s = snapshot
            if (s == null) {
                CircularProgressIndicator()
            } else {
                InfoCard(title = stringResource(R.string.thermal_live_reading)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusDot(dotLevelFor(s.status))
                        Spacer(Modifier.width(8.dp))
                        Text(thermalLabel(s.status), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(10.dp))
                    SpecRow(
                        stringResource(R.string.spec_battery_temp),
                        s.batteryTempCelsius.getOrNull()?.let { UnitFormatter.formatTemperature(it) } ?: stringResource(R.string.not_available)
                    )
                    SpecRow(
                        stringResource(R.string.thermal_headroom),
                        s.headroom.getOrNull()?.let { "%.2f".format(it) } ?: stringResource(R.string.not_available)
                    )
                    if (!s.isApiSupported) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(R.string.thermal_not_supported_note),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (s.status == ThermalLevel.SEVERE || s.status == ThermalLevel.CRITICAL ||
                        s.status == ThermalLevel.EMERGENCY || s.status == ThermalLevel.SHUTDOWN
                    ) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            stringResource(R.string.thermal_throttling_note),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

private fun dotLevelFor(status: ThermalLevel): StatusDotLevel = when (status) {
    ThermalLevel.NORMAL -> StatusDotLevel.GREEN
    ThermalLevel.LIGHT -> StatusDotLevel.YELLOW
    ThermalLevel.MODERATE -> StatusDotLevel.ORANGE
    ThermalLevel.SEVERE, ThermalLevel.CRITICAL, ThermalLevel.EMERGENCY, ThermalLevel.SHUTDOWN -> StatusDotLevel.RED
    ThermalLevel.UNKNOWN -> StatusDotLevel.UNKNOWN
}

@Composable
private fun thermalLabel(level: ThermalLevel): String = when (level) {
    ThermalLevel.NORMAL -> stringResource(R.string.thermal_normal)
    ThermalLevel.LIGHT -> stringResource(R.string.thermal_light)
    ThermalLevel.MODERATE -> stringResource(R.string.thermal_moderate)
    ThermalLevel.SEVERE -> stringResource(R.string.thermal_severe)
    ThermalLevel.CRITICAL -> stringResource(R.string.thermal_critical)
    ThermalLevel.EMERGENCY -> stringResource(R.string.thermal_emergency)
    ThermalLevel.SHUTDOWN -> stringResource(R.string.thermal_shutdown)
    ThermalLevel.UNKNOWN -> stringResource(R.string.thermal_unknown)
}
