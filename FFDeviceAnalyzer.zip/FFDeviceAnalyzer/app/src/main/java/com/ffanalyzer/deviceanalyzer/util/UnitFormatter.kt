package com.ffanalyzer.deviceanalyzer.util

import java.util.Locale
import kotlin.math.roundToInt

object UnitFormatter {

    fun bytesToGb(bytes: Long): Double = bytes / (1024.0 * 1024.0 * 1024.0)

    fun formatGb(bytes: Long): String = String.format(Locale.US, "%.1f GB", bytesToGb(bytes))

    fun formatPercent(value: Float): String = "${value.roundToInt()}%"

    fun formatMhz(khz: Long): String = String.format(Locale.US, "%.2f GHz", khz / 1_000_000.0)

    fun formatHz(hz: Float): String = String.format(Locale.US, "%.0f Hz", hz)

    fun formatTemperature(celsius: Float): String = String.format(Locale.US, "%.1f°C", celsius)

    fun formatFps(fps: Double): String = String.format(Locale.US, "%.0f", fps)
}
