package com.ffanalyzer.deviceanalyzer.ui.screens.settings

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.ffanalyzer.deviceanalyzer.R
import com.ffanalyzer.deviceanalyzer.ui.components.InfoCard

@Composable
fun SettingsScreen(onOpenPrivacy: () -> Unit) {
    val context = LocalContext.current

    var dndSuggestion by remember { mutableStateOf(false) }
    var lowBatteryAlert by remember { mutableStateOf(true) }
    var highTempAlert by remember { mutableStateOf(true) }
    var storageAlert by remember { mutableStateOf(true) }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.settings_title), fontWeight = FontWeight.Bold) }) }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            InfoCard(title = stringResource(R.string.settings_optimization_tools)) {
                SettingsToggleRow(
                    label = stringResource(R.string.settings_dnd_suggestion),
                    checked = dndSuggestion,
                    onCheckedChange = { checked ->
                        dndSuggestion = checked
                        if (checked) {
                            // User-initiated only: opens the system screen to grant DND access,
                            // never toggled automatically without consent (spec §13).
                            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                        }
                    }
                )
                SettingsToggleRow(
                    label = stringResource(R.string.settings_low_battery_alert),
                    checked = lowBatteryAlert,
                    onCheckedChange = { lowBatteryAlert = it }
                )
                SettingsToggleRow(
                    label = stringResource(R.string.settings_high_temp_alert),
                    checked = highTempAlert,
                    onCheckedChange = { highTempAlert = it }
                )
                SettingsToggleRow(
                    label = stringResource(R.string.settings_storage_alert),
                    checked = storageAlert,
                    onCheckedChange = { storageAlert = it }
                )
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = {
                    // Sends user to system app-usage-access list; they choose what to close.
                    // The app never force-kills processes itself.
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_USAGE_ACCESS_SETTINGS))
                }) {
                    Text(stringResource(R.string.settings_background_apps))
                }
            }

            Spacer(Modifier.height(16.dp))
            InfoCard(title = stringResource(R.string.settings_about)) {
                TextButton(onClick = onOpenPrivacy) {
                    Text(stringResource(R.string.privacy_title))
                }
            }
        }
    }
}

@Composable
private fun SettingsToggleRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
